<?php
session_start(); 


function conectarDB() {
    $serverName = "DESKTOP-IJP72TQ\SQLL"; // Cambia esto por el nombre de tu servidor
    $database = "tienda"; // Cambia esto por tu base de datos
    $username = "tienda"; // Cambia esto por tu usuario
    $password = "1234"; // Cambia esto por tu contraseña

    try {
        $conn = new PDO("sqlsrv:server=$serverName;Database=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("Error de conexión: " . $e->getMessage());
    }
}

$conn = conectarDB();

$mensaje = "";
$accion = $_POST['accion'] ?? null;

if ($accion == 'crear' || $accion == 'actualizar') {
    $nombre = $_POST['nombre'];
    $documento = $_POST['documento'];
    $telefono = $_POST['telefono'];
    $email = $_POST['email'];
    
    if ($accion == 'crear') {
        $sql = "INSERT INTO RegistroUsuario (nombre, documento, telefono, email) VALUES (?, ?, ?, ?)";
    } else {
        $id = $_POST['id'];
        $sql = "UPDATE RegistroUsuario SET nombre=?, documento=?, telefono=?, email=? WHERE id=?";
    }

    $stmt = $conn->prepare($sql);
    
    try {
        if ($accion == 'crear') {
            $stmt->execute([$nombre, $documento, $telefono, $email]);
            $_SESSION['mensaje'] = "Usuario registrado exitosamente.";
        } else {
            $stmt->execute([$nombre, $documento, $telefono, $email, $id]);
            $_SESSION['mensaje'] = "Usuario actualizado exitosamente.";
        }
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit();
    } catch (PDOException $e) {
        $_SESSION['mensaje'] = "Error: " . $e->getMessage();
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit();
    }
}

if ($accion == 'eliminar') {
    $id = $_POST['id'];
    $sql = "DELETE FROM RegistroUsuario WHERE id=?";
    $stmt = $conn->prepare($sql);

    try {
        $stmt->execute([$id]);
        $_SESSION['mensaje'] = "Usuario eliminado exitosamente.";
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit();
    } catch (PDOException $e) {
        $_SESSION['mensaje'] = "Error al eliminar: " . $e->getMessage();
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit();
    }
}

if ($accion == 'buscar') {
    $id = $_POST['idBuscar'];
    $sql = "SELECT * FROM RegistroUsuario WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($usuario) {
        $_POST['nombre'] = $usuario['nombre'];
        $_POST['documento'] = $usuario['documento'];
        $_POST['telefono'] = $usuario['telefono'];
        $_POST['email'] = $usuario['email'];
        $_POST['id'] = $usuario['id'];
    } else {
        $_SESSION['mensaje'] = "Usuario no encontrado.";
    }
}

$mensaje = $_SESSION['mensaje'] ?? '';
unset($_SESSION['mensaje']); 
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Registro de Usuario</title>
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            flex-direction: column;
        }
        .form-container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
        }
        input[type="text"], input[type="email"] {
            width: 100%;
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .mensaje {
            margin-top: 20px;
            color: green;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Registrar/Actualizar Usuario</h1>
        <form action="" method="POST">
            <input type="hidden" name="id" id="id" value="<?php echo $_POST['id'] ?? ''; ?>">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required value="<?php echo $_POST['nombre'] ?? ''; ?>">

            <label for="documento">Documento:</label>
            <input type="text" id="documento" name="documento" required value="<?php echo $_POST['documento'] ?? ''; ?>">

            <label for="telefono">Teléfono:</label>
            <input type="text" id="telefono" name="telefono" required value="<?php echo $_POST['telefono'] ?? ''; ?>">

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required value="<?php echo $_POST['email'] ?? ''; ?>">

            <input type="submit" name="accion" value="crear">
            <input type="submit" name="accion" value="actualizar" style="display: <?php echo isset($_POST['id']) ? 'inline' : 'none'; ?>;">
        </form>
        
        <?php if ($mensaje): ?>
            <div class="mensaje"><?php echo $mensaje; ?></div>
        <?php endif; ?>
        
        <h2>Buscar Usuario por ID</h2>
        <form action="" method="POST">
            <label for="idBuscar">ID del Usuario:</label>
            <input type="text" id="idBuscar" name="idBuscar" required>
            <input type="submit" name="accion" value="buscar">
        </form>
        
        <h2>Eliminar Usuario</h2>
        <form action="" method="POST">
            <label for="idEliminar">ID del Usuario a Eliminar:</label>
            <input type="text" id="idEliminar" name="id" required>
            <input type="submit" name="accion" value="eliminar" onclick="return confirm('¿Estás seguro de eliminar este usuario?');">
        </form>
    </div>
</body>
</html>

<?php
$conn = null;
?>




