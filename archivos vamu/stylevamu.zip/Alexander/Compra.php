<?php

function conectarDB() {
    $serverName = "DESKTOP-IJP72TQ\SQLL"; // Cambia esto por el nombre de tu servidor
    $database = "tienda"; // Cambia esto por tu base de datos
    $username = "tienda"; // Cambia esto por tu usuario
    $password = "1234"; // Cambia esto por tu contraseña

    try {
        $conn = new PDO("sqlsrv:server=$serverName;Database=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("Error de conexión: " . $e->getMessage());
    }
}

$conn = conectarDB();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $direccion = $_POST['direccion'];
    $documento = $_POST['documento'];
    $producto = $_POST['producto'];
    $telefono = $_POST['telefono'];
    $fecha = $_POST['fecha'];

  
    $sql = "INSERT INTO Compras (nombre, apellido, direccion, documento, producto, telefono, fecha) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    
    try {
        $stmt->execute([$nombre, $apellido, $direccion, $documento, $producto, $telefono, $fecha]);
        echo "Compra registrada exitosamente.";
    } catch (PDOException $e) {
        echo "Error al registrar la compra: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Compra</title>
    <style>
        body {
            background-color: #f0f0f0; 
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .form-container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 300px; 
            text-align: center;
        }
        input[type="text"], input[type="date"] {
            width: 100%;
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"], .btn-volver {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }
        input[type="submit"]:hover, .btn-volver:hover {
            background-color: #0056b3; 
        }
        .volver {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Realiza tu compra</h1>
        <form action="" method="POST">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>

            <label for="apellido">Apellido:</label>
            <input type="text" id="apellido" name="apellido" required>

            <label for="direccion">Dirección:</label>
            <input type="text" id="direccion" name="direccion" required>

            <label for="documento">Documento:</label>
            <input type="text" id="documento" name="documento" required>

            <label for="producto">Producto:</label>
            <input type="text" id="producto" name="producto" required>

            <label for="telefono">Teléfono:</label>
            <input type="text" id="telefono" name="telefono" required>

            <label for="fecha">Fecha:</label>
            <input type="date" id="fecha" name="fecha" required>

            <input type="submit" value="Enviar">
        </form>
        <div class="volver">
            <a href="javascript:history.back()">
                <button class="btn-volver">Volver</button>
            </a>
        </div>
    </div>
</body>
</html>

<?php
$conn = null;
?>



